

export class Blog {
    url: string = '';
    Title: string = '';
}